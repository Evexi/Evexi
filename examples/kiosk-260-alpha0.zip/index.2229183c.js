(function () {
function $parcel$interopDefault(a) {
  return a && a.__esModule ? a.default : a;
}
function $7be2faeb44e44bf3$var$asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) resolve(value);
    else Promise.resolve(value).then(_next, _throw);
}
function $7be2faeb44e44bf3$export$2e2bcd8739ae039(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                $7be2faeb44e44bf3$var$asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                $7be2faeb44e44bf3$var$asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}

function $091363785a82a984$export$2e2bcd8739ae039(instance, Constructor) {
    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function");
}

function $59a181a5ef8aab9b$var$_defineProperties(target, props) {
    for(var i = 0; i < props.length; i++){
        var descriptor = props[i];
        descriptor.enumerable = descriptor.enumerable || false;
        descriptor.configurable = true;
        if ("value" in descriptor) descriptor.writable = true;
        Object.defineProperty(target, descriptor.key, descriptor);
    }
}
function $59a181a5ef8aab9b$export$2e2bcd8739ae039(Constructor, protoProps, staticProps) {
    if (protoProps) $59a181a5ef8aab9b$var$_defineProperties(Constructor.prototype, protoProps);
    if (staticProps) $59a181a5ef8aab9b$var$_defineProperties(Constructor, staticProps);
    return Constructor;
}

function $9a0771ced2459b50$export$2e2bcd8739ae039(obj, key, value) {
    if (key in obj) Object.defineProperty(obj, key, {
        value: value,
        enumerable: true,
        configurable: true,
        writable: true
    });
    else obj[key] = value;
    return obj;
}



var $79ae1ae4a16b6dd8$exports = {};
/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var $79ae1ae4a16b6dd8$var$runtime = function(exports) {
    var define = function define(obj, key, value) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
        return obj[key];
    };
    var wrap = function wrap(innerFn, outerFn, self, tryLocsList) {
        // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
        var generator = Object.create(protoGenerator.prototype);
        var context = new Context(tryLocsList || []);
        // The ._invoke method unifies the implementations of the .next,
        // .throw, and .return methods.
        generator._invoke = makeInvokeMethod(innerFn, self, context);
        return generator;
    };
    var tryCatch = // Try/catch helper to minimize deoptimizations. Returns a completion
    // record like context.tryEntries[i].completion. This interface could
    // have been (and was previously) designed to take a closure to be
    // invoked without arguments, but in all the cases we care about we
    // already have an existing method we want to call, so there's no need
    // to create a new function object. We can even get away with assuming
    // the method takes exactly one argument, since that happens to be true
    // in every case, so we don't have to touch the arguments object. The
    // only additional allocation required is the completion record, which
    // has a stable shape and so hopefully should be cheap to allocate.
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    };
    var Generator = // Dummy constructor functions that we use as the .constructor and
    // .constructor.prototype properties for functions that return Generator
    // objects. For full spec compliance, you may wish to configure your
    // minifier not to mangle the names of these two functions.
    function Generator() {};
    var GeneratorFunction = function GeneratorFunction() {};
    var GeneratorFunctionPrototype = function GeneratorFunctionPrototype() {};
    var defineIteratorMethods = // Helper for defining the .next, .throw, and .return methods of the
    // Iterator interface in terms of a single ._invoke method.
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    };
    var AsyncIterator = function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if (record.type === "throw") reject(record.arg);
            else {
                var result = record.arg;
                var value1 = result.value;
                if (value1 && typeof value1 === "object" && hasOwn.call(value1, "__await")) return PromiseImpl.resolve(value1.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                });
                return PromiseImpl.resolve(value1).then(function(unwrapped) {
                    // When a yielded Promise is resolved, its final value becomes
                    // the .value of the Promise<{value,done}> result for the
                    // current iteration.
                    result.value = unwrapped;
                    resolve(result);
                }, function(error) {
                    // If a rejected Promise was yielded, throw the rejection back
                    // into the async generator function so it can be handled there.
                    return invoke("throw", error, resolve, reject);
                });
            }
        }
        var previousPromise;
        function enqueue(method, arg) {
            function callInvokeWithMethodAndArg() {
                return new PromiseImpl(function(resolve, reject) {
                    invoke(method, arg, resolve, reject);
                });
            }
            return previousPromise = // If enqueue has been called before, then we want to wait until
            // all previous Promises have been resolved before calling invoke,
            // so that results are always delivered in the correct order. If
            // enqueue has not been called before, then it is important to
            // call invoke immediately, without waiting on a callback to fire,
            // so that the async generator function has the opportunity to do
            // any necessary setup in a predictable way. This predictability
            // is why the Promise constructor synchronously invokes its
            // executor callback, and why async functions synchronously
            // execute code before the first await. Since we implement simple
            // async functions in terms of async generators, it is especially
            // important to get this right, even though it requires care.
            previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, // Avoid propagating failures to Promises returned by later
            // invocations of the iterator.
            callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
        }
        // Define the unified helper method that is used to implement .next,
        // .throw, and .return (see defineIteratorMethods).
        this._invoke = enqueue;
    };
    var makeInvokeMethod = function makeInvokeMethod(innerFn, self, context) {
        var state = GenStateSuspendedStart;
        return function invoke(method, arg) {
            if (state === GenStateExecuting) throw new Error("Generator is already running");
            if (state === GenStateCompleted) {
                if (method === "throw") throw arg;
                // Be forgiving, per 25.3.3.3.3 of the spec:
                // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
                return doneResult();
            }
            context.method = method;
            context.arg = arg;
            while(true){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if (context.method === "next") // Setting context._sent for legacy support of Babel's
                // function.sent implementation.
                context.sent = context._sent = context.arg;
                else if (context.method === "throw") {
                    if (state === GenStateSuspendedStart) {
                        state = GenStateCompleted;
                        throw context.arg;
                    }
                    context.dispatchException(context.arg);
                } else if (context.method === "return") context.abrupt("return", context.arg);
                state = GenStateExecuting;
                var record = tryCatch(innerFn, self, context);
                if (record.type === "normal") {
                    // If an exception is thrown from innerFn, we leave state ===
                    // GenStateExecuting and loop back for another invocation.
                    state = context.done ? GenStateCompleted : GenStateSuspendedYield;
                    if (record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                } else if (record.type === "throw") {
                    state = GenStateCompleted;
                    // Dispatch the exception by looping back around to the
                    // context.dispatchException(context.arg) call above.
                    context.method = "throw";
                    context.arg = record.arg;
                }
            }
        };
    };
    var pushTryEntry = function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        if (1 in locs) entry.catchLoc = locs[1];
        if (2 in locs) {
            entry.finallyLoc = locs[2];
            entry.afterLoc = locs[3];
        }
        this.tryEntries.push(entry);
    };
    var resetTryEntry = function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal";
        delete record.arg;
        entry.completion = record;
    };
    var Context = function Context(tryLocsList) {
        // The root entry object (effectively a try statement without a catch
        // or a finally block) gives us a place to store values thrown from
        // locations where there is no enclosing try statement.
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ];
        tryLocsList.forEach(pushTryEntry, this);
        this.reset(true);
    };
    var values = function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if (typeof iterable.next === "function") return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next1 = function next() {
                    while(++i < iterable.length)if (hasOwn.call(iterable, i)) {
                        next.value = iterable[i];
                        next.done = false;
                        return next;
                    }
                    next.value = undefined;
                    next.done = true;
                    return next;
                };
                return next1.next = next1;
            }
        }
        // Return an iterator with no values.
        return {
            next: doneResult
        };
    };
    var doneResult = function doneResult() {
        return {
            value: undefined,
            done: true
        };
    };
    var Op = Object.prototype;
    var hasOwn = Op.hasOwnProperty;
    var undefined; // More compressible than void 0.
    var $Symbol = typeof Symbol === "function" ? Symbol : {};
    var iteratorSymbol = $Symbol.iterator || "@@iterator";
    var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
    var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    try {
        // IE 8 has a broken Object.defineProperty that only works on DOM objects.
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    exports.wrap = wrap;
    var GenStateSuspendedStart = "suspendedStart";
    var GenStateSuspendedYield = "suspendedYield";
    var GenStateExecuting = "executing";
    var GenStateCompleted = "completed";
    // Returning this object from the innerFn has the same effect as
    // breaking out of the dispatch switch statement.
    var ContinueSentinel = {};
    // This is a polyfill for %IteratorPrototype% for environments that
    // don't natively support it.
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf;
    var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    if (NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    GeneratorFunction.prototype = GeneratorFunctionPrototype;
    define(Gp, "constructor", GeneratorFunctionPrototype);
    define(GeneratorFunctionPrototype, "constructor", GeneratorFunction);
    GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction");
    exports.isGeneratorFunction = function(genFun) {
        var ctor = typeof genFun === "function" && genFun.constructor;
        return ctor ? ctor === GeneratorFunction || // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction" : false;
    };
    exports.mark = function(genFun) {
        if (Object.setPrototypeOf) Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
        else {
            genFun.__proto__ = GeneratorFunctionPrototype;
            define(genFun, toStringTagSymbol, "GeneratorFunction");
        }
        genFun.prototype = Object.create(Gp);
        return genFun;
    };
    // Within the body of any async function, `await x` is transformed to
    // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
    // `hasOwn.call(value, "__await")` to determine if the yielded value is
    // meant to be awaited.
    exports.awrap = function(arg) {
        return {
            __await: arg
        };
    };
    defineIteratorMethods(AsyncIterator.prototype);
    define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    });
    exports.AsyncIterator = AsyncIterator;
    // Note that simple async functions are implemented on top of
    // AsyncIterator objects; they just return a Promise for the value of
    // the final result produced by the iterator.
    exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        if (PromiseImpl === void 0) PromiseImpl = Promise;
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports.isGeneratorFunction(outerFn) ? iter // If outerFn is a generator, return the full iterator.
         : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    };
    // Call delegate.iterator[context.method](context.arg) and handle the
    // result, either by returning a { value, done } result from the
    // delegate iterator, or by modifying context.method and context.arg,
    // setting context.delegate to null, and returning the ContinueSentinel.
    function maybeInvokeDelegate(delegate, context) {
        var method = delegate.iterator[context.method];
        if (method === undefined) {
            // A .throw or .return when the delegate iterator has no .throw
            // method always terminates the yield* loop.
            context.delegate = null;
            if (context.method === "throw") {
                // Note: ["return"] must be used for ES3 parsing compatibility.
                if (delegate.iterator["return"]) {
                    // If the delegate iterator has a return method, give it a
                    // chance to clean up.
                    context.method = "return";
                    context.arg = undefined;
                    maybeInvokeDelegate(delegate, context);
                    if (context.method === "throw") // If maybeInvokeDelegate(context) changed context.method from
                    // "return" to "throw", let that override the TypeError below.
                    return ContinueSentinel;
                }
                context.method = "throw";
                context.arg = new TypeError("The iterator does not provide a 'throw' method");
            }
            return ContinueSentinel;
        }
        var record = tryCatch(method, delegate.iterator, context.arg);
        if (record.type === "throw") {
            context.method = "throw";
            context.arg = record.arg;
            context.delegate = null;
            return ContinueSentinel;
        }
        var info = record.arg;
        if (!info) {
            context.method = "throw";
            context.arg = new TypeError("iterator result is not an object");
            context.delegate = null;
            return ContinueSentinel;
        }
        if (info.done) {
            // Assign the result of the finished delegate to the temporary
            // variable specified by delegate.resultName (see delegateYield).
            context[delegate.resultName] = info.value;
            // Resume execution at the desired location (see delegateYield).
            context.next = delegate.nextLoc;
            // If context.method was "throw" but the delegate handled the
            // exception, let the outer generator proceed normally. If
            // context.method was "next", forget context.arg since it has been
            // "consumed" by the delegate iterator. If context.method was
            // "return", allow the original .return call to continue in the
            // outer generator.
            if (context.method !== "return") {
                context.method = "next";
                context.arg = undefined;
            }
        } else // Re-yield the result returned by the delegate method.
        return info;
        // The delegate iterator is finished, so forget it and continue with
        // the outer generator.
        context.delegate = null;
        return ContinueSentinel;
    }
    // Define Generator.prototype.{next,throw,return} in terms of the
    // unified ._invoke helper method.
    defineIteratorMethods(Gp);
    define(Gp, toStringTagSymbol, "Generator");
    // A Generator should always return itself as the iterator object when the
    // @@iterator function is called on it. Some browsers' implementations of the
    // iterator prototype chain incorrectly implement this, causing the Generator
    // object to not be returned from this call. This ensures that doesn't happen.
    // See https://github.com/facebook/regenerator/issues/274 for more details.
    define(Gp, iteratorSymbol, function() {
        return this;
    });
    define(Gp, "toString", function() {
        return "[object Generator]";
    });
    exports.keys = function(object) {
        var keys = [];
        for(var key1 in object)keys.push(key1);
        keys.reverse();
        // Rather than returning an object with a next method, we keep
        // things simple and return the next function itself.
        return function next() {
            while(keys.length){
                var key = keys.pop();
                if (key in object) {
                    next.value = key;
                    next.done = false;
                    return next;
                }
            }
            // To avoid creating an additional object, we just hang the .value
            // and .done properties off the next function object itself. This
            // also ensures that the minifier will not anonymize the function.
            next.done = true;
            return next;
        };
    };
    exports.values = values;
    Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            this.prev = 0;
            this.next = 0;
            // Resetting context._sent for legacy support of Babel's
            // function.sent implementation.
            this.sent = this._sent = undefined;
            this.done = false;
            this.delegate = null;
            this.method = "next";
            this.arg = undefined;
            this.tryEntries.forEach(resetTryEntry);
            if (!skipTempReset) {
                for(var name in this)// Not sure about the optimal order of these conditions:
                if (name.charAt(0) === "t" && hasOwn.call(this, name) && !isNaN(+name.slice(1))) this[name] = undefined;
            }
        },
        stop: function stop() {
            this.done = true;
            var rootEntry = this.tryEntries[0];
            var rootRecord = rootEntry.completion;
            if (rootRecord.type === "throw") throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            var handle = function handle(loc, caught) {
                record.type = "throw";
                record.arg = exception;
                context.next = loc;
                if (caught) {
                    // If the dispatched exception was caught by a catch block,
                    // then let that catch block handle the exception normally.
                    context.method = "next";
                    context.arg = undefined;
                }
                return !!caught;
            };
            if (this.done) throw exception;
            var context = this;
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                var record = entry.completion;
                if (entry.tryLoc === "root") // Exception thrown outside of any try block that could handle
                // it, so set the completion value of the entire function to
                // throw the exception.
                return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc");
                    var hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, true);
                        else if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, true);
                    } else if (hasFinally) {
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else throw new Error("try statement without catch or finally");
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            if (finallyEntry && (type === "break" || type === "continue") && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc) // Ignore the finally entry if control is not jumping to a
            // location outside the try/catch block.
            finallyEntry = null;
            var record = finallyEntry ? finallyEntry.completion : {};
            record.type = type;
            record.arg = arg;
            if (finallyEntry) {
                this.method = "next";
                this.next = finallyEntry.finallyLoc;
                return ContinueSentinel;
            }
            return this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if (record.type === "throw") throw record.arg;
            if (record.type === "break" || record.type === "continue") this.next = record.arg;
            else if (record.type === "return") {
                this.rval = this.arg = record.arg;
                this.method = "return";
                this.next = "end";
            } else if (record.type === "normal" && afterLoc) this.next = afterLoc;
            return ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) {
                    this.complete(entry.completion, entry.afterLoc);
                    resetTryEntry(entry);
                    return ContinueSentinel;
                }
            }
        },
        "catch": function(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if (record.type === "throw") {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            // The context.catch method must only be called with a location
            // argument that corresponds to a known catch block.
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            };
            if (this.method === "next") // Deliberately forget the last sent value so that we don't
            // accidentally pass it on to the delegate.
            this.arg = undefined;
            return ContinueSentinel;
        }
    };
    // Regardless of whether this script is executing as a CommonJS module
    // or not, return the runtime object so that we can declare the variable
    // regeneratorRuntime in the outer scope, which allows this module to be
    // injected easily by `bin/regenerator --include-runtime script.js`.
    return exports;
}($79ae1ae4a16b6dd8$exports);
try {
    regeneratorRuntime = $79ae1ae4a16b6dd8$var$runtime;
} catch (accidentalStrictMode) {
    // This module should not be running in strict mode, so the above
    // assignment should always work unless something is misconfigured. Just
    // in case runtime.js accidentally runs in strict mode, in modern engines
    // we can explicitly access globalThis. In older engines we can escape
    // strict mode using a global Function call. This could conceivably fail
    // if a Content Security Policy forbids using Function, but in that case
    // the proper solution is to fix the accidental strict mode problem. If
    // you've misconfigured your bundler to force strict mode and applied a
    // CSP to forbid Function, and you're not willing to fix either of those
    // problems, please detail your unique predicament in a GitHub issue.
    if (typeof globalThis === "object") globalThis.regeneratorRuntime = $79ae1ae4a16b6dd8$var$runtime;
    else Function("r", "regeneratorRuntime = r")($79ae1ae4a16b6dd8$var$runtime);
}



/**
 * logger
 */ var $b5bc41ceae313618$export$bef1f36f5486a6a3 = new /*#__PURE__*/ (function() {
    "use strict";
    function _class() {
        $091363785a82a984$export$2e2bcd8739ae039(this, _class);
        // Add to div
        $9a0771ced2459b50$export$2e2bcd8739ae039(this, "logs", document.getElementById('logs'));
    }
    $59a181a5ef8aab9b$export$2e2bcd8739ae039(_class, [
        {
            key: "info",
            value: function info($b5bc41ceae313618$export$bef1f36f5486a6a3) {
                this.logs.innerHTML += '<span style=\'background-color: gray\'>' + $b5bc41ceae313618$export$bef1f36f5486a6a3 + '</span><br/>';
                if ($b5bc41ceae313618$export$bef1f36f5486a6a3) console.log($b5bc41ceae313618$export$bef1f36f5486a6a3);
            }
        },
        {
            key: "success",
            value: function success($b5bc41ceae313618$export$bef1f36f5486a6a3) {
                this.logs.innerHTML += '<span style=\'background-color: darkgreen\'>' + $b5bc41ceae313618$export$bef1f36f5486a6a3 + '</span><br/>';
                if ($b5bc41ceae313618$export$bef1f36f5486a6a3) console.log($b5bc41ceae313618$export$bef1f36f5486a6a3);
            }
        },
        {
            key: "error",
            value: function error($b5bc41ceae313618$export$bef1f36f5486a6a3) {
                this.logs.innerHTML += '<span style=\'background-color: darkred\'>' + $b5bc41ceae313618$export$bef1f36f5486a6a3 + '</span><br/>';
                if ($b5bc41ceae313618$export$bef1f36f5486a6a3) console.log($b5bc41ceae313618$export$bef1f36f5486a6a3);
            }
        },
        {
            key: "clear",
            value: function clear() {
                this.logs.innerHTML = '';
            }
        }
    ]);
    return _class;
}());


/**
 * Evexi API
 * Version 2.6.0-alpha.6
 */ var $35968c1d1652764a$var$t, $35968c1d1652764a$var$n, $35968c1d1652764a$var$e;
!function(t) {
    t.INFO = "info", t.LOG = "log", t.STORAGE_GET = "storage.get", t.STORAGE_PUT = "storage.put", t.STORAGE_DELETE = "storage.delete", t.STORAGE_LIST = "storage.list", t.STORAGE_CLEAR = "storage.clear", t.STORAGE_DOWNLOAD = "storage.download", t.STORAGE_EXISTS = "storage.exists", t.INTERACT_CREATE = "interact.create", t.INTERACT_START = "interact.start", t.INTERACT_DESTROY = "interact.destroy", t.INTERACT_MESSAGE = "interact.message", t.INTERACT_KICK = "interact.kick", t.KIOSK_BARCODE = "kiosk.barcode", t.KIOSK_PRINTER = "kiosk.printer", t.PROXY = "proxy", t.ENV_VAR = "envVar";
}($35968c1d1652764a$var$t || ($35968c1d1652764a$var$t = {})), function(t) {
    t.SSSP2 = "SSSP2", t.HTML = "HTML", t.TIZEN = "TIZEN", t.KIOSK = "KIOSK";
}($35968c1d1652764a$var$n || ($35968c1d1652764a$var$n = {})), function(t) {
    var n, e, o;
    (n = t.PrinterPort || (t.PrinterPort = {})).PRINTERPORT0 = "PRINTERPORT0", n.PRINTERPORT1 = "PRINTERPORT1", n.PRINTERPORT2 = "PRINTERPORT2", (e = t.PrinterParity || (t.PrinterParity = {})).NONE = "NONE", e.ODD = "ODD", e.EVEN = "EVEN", (o = t.PrinterDataBits || (t.PrinterDataBits = {})).BITS5 = "BITS5", o.BITS6 = "BITS6", o.BITS7 = "BITS7", o.BITS8 = "BITS8";
}($35968c1d1652764a$var$e || ($35968c1d1652764a$var$e = {}));
var $35968c1d1652764a$var$o = function(t1, n1) {
    return $35968c1d1652764a$var$o = Object.setPrototypeOf || ({
        __proto__: []
    }) instanceof Array && function(t, n) {
        t.__proto__ = n;
    } || function(t, n) {
        for(var e in n)Object.prototype.hasOwnProperty.call(n, e) && (t[e] = n[e]);
    }, $35968c1d1652764a$var$o(t1, n1);
};
var $35968c1d1652764a$var$i = function() {
    return $35968c1d1652764a$var$i = Object.assign || function(t) {
        for(var n, e = 1, o = arguments.length; e < o; e++)for(var i in n = arguments[e])Object.prototype.hasOwnProperty.call(n, i) && (t[i] = n[i]);
        return t;
    }, $35968c1d1652764a$var$i.apply(this, arguments);
};
function $35968c1d1652764a$var$r(t2, n2, e, o) {
    return new (e || (e = Promise))(function(i, r) {
        var s = function s(t) {
            try {
                a(o.next(t));
            } catch (n) {
                r(n);
            }
        };
        var c = function c(t) {
            try {
                a(o["throw"](t));
            } catch (n) {
                r(n);
            }
        };
        var a = function a(t3) {
            var _$n;
            t3.done ? i(t3.value) : (_$n = t3.value, _$n instanceof e ? _$n : new e(function(t) {
                t(_$n);
            })).then(s, c);
        };
        a((o = o.apply(t2, n2 || [])).next());
    });
}
function $35968c1d1652764a$var$s(t, n) {
    var c1 = function c1(r2) {
        return function(c3) {
            return function(r) {
                if (e) throw new TypeError("Generator is already executing.");
                for(; s;)try {
                    if (e = 1, o && (i = 2 & r[0] ? o["return"] : r[0] ? o["throw"] || ((i = o["return"]) && i.call(o), 0) : o.next) && !(i = i.call(o, r[1])).done) return i;
                    switch(o = 0, i && (r = [
                        2 & r[0],
                        i.value
                    ]), r[0]){
                        case 0:
                        case 1:
                            i = r;
                            break;
                        case 4:
                            return s.label++, {
                                value: r[1],
                                done: !1
                            };
                        case 5:
                            s.label++, o = r[1], r = [
                                0
                            ];
                            continue;
                        case 7:
                            r = s.ops.pop(), s.trys.pop();
                            continue;
                        default:
                            if (!(i = s.trys, (i = i.length > 0 && i[i.length - 1]) || 6 !== r[0] && 2 !== r[0])) {
                                s = 0;
                                continue;
                            }
                            if (3 === r[0] && (!i || r[1] > i[0] && r[1] < i[3])) {
                                s.label = r[1];
                                break;
                            }
                            if (6 === r[0] && s.label < i[1]) {
                                s.label = i[1], i = r;
                                break;
                            }
                            if (i && s.label < i[2]) {
                                s.label = i[2], s.ops.push(r);
                                break;
                            }
                            i[2] && s.ops.pop(), s.trys.pop();
                            continue;
                    }
                    r = n.call(t, s);
                } catch (c) {
                    r = [
                        6,
                        c
                    ], o = 0;
                } finally{
                    e = i = 0;
                }
                if (5 & r[0]) throw r[1];
                return {
                    value: r[0] ? r[1] : void 0,
                    done: !0
                };
            }([
                r2,
                c3
            ]);
        };
    };
    var e, o, i, r1, s = {
        label: 0,
        sent: function sent() {
            if (1 & i[0]) throw i[1];
            return i[1];
        },
        trys: [],
        ops: []
    };
    return r1 = {
        next: c1(0),
        "throw": c1(1),
        "return": c1(2)
    }, "function" == typeof Symbol && (r1[Symbol.iterator] = function() {
        return this;
    }), r1;
}
function $35968c1d1652764a$var$c(t, n) {
    var e1 = new Promise(function(n, e) {
        var o = window.setTimeout(function() {
            window.clearTimeout(o), e("Timed out in " + t + "ms.");
        }, t);
    });
    return Promise.race([
        n,
        e1
    ]);
}
function $35968c1d1652764a$var$a(t) {
    try {
        window.parent.postMessage(JSON.stringify($35968c1d1652764a$var$i({}, t)), "*");
    } catch (n) {
        throw new Error("wrapperNoListener error");
    }
}
function $35968c1d1652764a$var$u(t4, n, e2) {
    return $35968c1d1652764a$var$r(this, void 0, void 0, function() {
        var o1;
        return $35968c1d1652764a$var$s(this, function(r) {
            switch(r.label){
                case 0:
                    return r.trys.push([
                        0,
                        2,
                        ,
                        3
                    ]), [
                        4,
                        $35968c1d1652764a$var$c(e2 || 5e3, new Promise(function(e) {
                            var o, _$r, _$s;
                            o = function o(t) {
                                e(t.response);
                            }, _$r = $35968c1d1652764a$var$i({
                                action: t4.action
                            }, n), _$s = function(t5) {
                                var _$n, _$e = JSON.parse(t5.data);
                                if (_$e) try {
                                    (_$n = _$r, Object.keys(_$n)).forEach(function(t) {
                                        if (_$r[t] !== _$e[t]) throw new Error("");
                                    }), window.removeEventListener("message", _$s, !0), o(_$e);
                                } catch (t) {}
                            }, window.addEventListener("message", _$s, !0), window.parent.postMessage(JSON.stringify($35968c1d1652764a$var$i({}, t4)), "*");
                        }))
                    ];
                case 1:
                    return [
                        2,
                        r.sent()
                    ];
                case 2:
                    throw o1 = r.sent(), new Error(o1);
                case 3:
                    return [
                        2
                    ];
            }
        });
    });
}
var $35968c1d1652764a$var$f, $35968c1d1652764a$var$l, $35968c1d1652764a$var$h, $35968c1d1652764a$var$d, $35968c1d1652764a$var$p, $35968c1d1652764a$var$v, $35968c1d1652764a$var$E, $35968c1d1652764a$var$T, $35968c1d1652764a$var$S, $35968c1d1652764a$var$O, $35968c1d1652764a$var$I, $35968c1d1652764a$var$R, $35968c1d1652764a$var$g, $35968c1d1652764a$var$A, $35968c1d1652764a$var$N, $35968c1d1652764a$var$y = new function() {
    this.all = {
        get: function get(n) {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.STORAGE_GET,
                name: n
            }, {
                name: n
            });
        },
        put: function put(n, e) {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.STORAGE_PUT,
                name: n,
                data: e
            }, {
                name: n
            });
        },
        del: function del(n) {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.STORAGE_DELETE,
                name: n
            }, {
                name: n
            });
        },
        list: function list() {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.STORAGE_LIST
            });
        },
        clear: function clear() {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.STORAGE_CLEAR
            });
        },
        download: function download(n, e) {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.STORAGE_DOWNLOAD,
                url: n,
                name: e
            }, {
                name: e
            });
        },
        exists: function exists(n) {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.STORAGE_EXISTS,
                name: n
            }, {
                name: n
            });
        }
    };
};
!function(t) {
    t.ERROR = "error", t.LOG = "log", t.INFO = "info", t.WARN = "warn", t.NONE = "none";
}($35968c1d1652764a$var$f || ($35968c1d1652764a$var$f = {})), function(t) {
    t.AUTH = "Auth";
}($35968c1d1652764a$var$l || ($35968c1d1652764a$var$l = {})), function(t) {
    t.LANDSCAPE = "landscape", t.PORTRAIT = "portrait", t.ANY = "any";
}($35968c1d1652764a$var$h || ($35968c1d1652764a$var$h = {})), function(t) {
    t.NAME = "name", t["-NAME"] = "-name", t.UPDATED_AT = "updated_at", t["-UPDATED_AT"] = "-updated_at", t.CREATED_AT = "-created_at", t["-CREATED_AT"] = "-created_at";
}($35968c1d1652764a$var$d || ($35968c1d1652764a$var$d = {})), function(t) {
    t.DEBUG = "debug", t.INFO = "info", t.WARN = "warn", t.ERROR = "error";
}($35968c1d1652764a$var$p || ($35968c1d1652764a$var$p = {})), function(t) {
    t.SEEN = "seen", t.PENDING = "pending";
}($35968c1d1652764a$var$v || ($35968c1d1652764a$var$v = {})), function(t) {
    t.PLAYLIST = "playlist", t.SCHEDULE = "schedule";
}($35968c1d1652764a$var$E || ($35968c1d1652764a$var$E = {})), function(t) {
    t.OFFLINE = "Offline", t.ONLINE = "Online";
}($35968c1d1652764a$var$T || ($35968c1d1652764a$var$T = {})), function(t) {
    t.IMAGE = "image", t.TEXT = "text", t.VIDEO = "video", t.WEB = "web", t.RSS = "rss", t.PIP = "pip";
}($35968c1d1652764a$var$S || ($35968c1d1652764a$var$S = {})), function(t) {
    t.ACTIVE = "Active", t.INACTIVE = "Inactive";
}($35968c1d1652764a$var$O || ($35968c1d1652764a$var$O = {})), function(t) {
    t.SLIDE_LEFT = "slide-in-from-left", t.SLIDE_TOP = "slide-in-from-top", t.SLIDE_BOTTOM = "slide-in-from-bottom", t.SLIDE_RIGHT = "slide-in-from-right", t.FADE = "fade-in", t.ZOOM = "zoom-in";
}($35968c1d1652764a$var$I || ($35968c1d1652764a$var$I = {})), function(t) {
    t.SLIDE_LEFT = "slide-out-to-left", t.SLIDE_TOP = "slide-out-to-top", t.SLIDE_BOTTOM = "slide-out-to-bottom", t.SLIDE_RIGHT = "slide-out-to-right", t.FADE = "fade-out", t.ZOOM = "zoom-out";
}($35968c1d1652764a$var$R || ($35968c1d1652764a$var$R = {})), function(t) {
    t.MESSAGE = "message", t.CONNECT = "connect", t.DISCONNECT = "disconnect", t.KICK = "kick";
}($35968c1d1652764a$var$g || ($35968c1d1652764a$var$g = {})), function(t) {
    t.SSSP2 = "SSSP2", t.HTML = "HTML", t.TIZEN = "TIZEN", t.KIOSK = "KIOSK";
}($35968c1d1652764a$var$A || ($35968c1d1652764a$var$A = {})), function(t) {
    t.SP = "sp", t.SETTINGS = "settings", t.CLEAR_AND_RESTART = "clearrestart", t.REBOOT = "reboot", t.LOGS = "logs", t.PING = "ping", t.INTERACT = "interact", t.INTERACT_START = "interact:start", t.TRANSITION = "transition", t.HC_HEALTH = "health", t.HC_SETTINGS = "info:settings", t.HC_INFO = "info";
}($35968c1d1652764a$var$N || ($35968c1d1652764a$var$N = {}));
var $35968c1d1652764a$var$w, $35968c1d1652764a$var$_, $35968c1d1652764a$var$m = new function() {
    var n3 = this;
    this.all = {
        create: function create(n, e, o, r) {
            return $35968c1d1652764a$var$u($35968c1d1652764a$var$i($35968c1d1652764a$var$i($35968c1d1652764a$var$i({
                action: $35968c1d1652764a$var$t.INTERACT_CREATE,
                maxRuntime: n
            }, e && {
                clientUrl: e
            }), o && {
                maxClients: o
            }), r && {
                noCommunicationTimeout: r
            }));
        },
        start: function start() {
            return $35968c1d1652764a$var$a({
                action: $35968c1d1652764a$var$t.INTERACT_START
            });
        },
        destroy: function destroy() {
            n3.events = {}, $35968c1d1652764a$var$a({
                action: $35968c1d1652764a$var$t.INTERACT_DESTROY
            });
        },
        message: function message(n, e) {
            return $35968c1d1652764a$var$a($35968c1d1652764a$var$i({
                action: $35968c1d1652764a$var$t.INTERACT_MESSAGE,
                data: n
            }, e && {
                client: e
            }));
        },
        kick: function kick(n) {
            return $35968c1d1652764a$var$a({
                action: $35968c1d1652764a$var$t.INTERACT_KICK,
                client: n
            });
        },
        onMessage: function onMessage(t) {
            n3.events.onMessage = t;
        },
        onConnect: function onConnect(t) {
            n3.events.onConnect = t;
        },
        onDisconnect: function onDisconnect(t) {
            n3.events.onDisconnect = t;
        },
        onKick: function onKick(t) {
            n3.events.onKick = t;
        }
    }, this.events = {}, window.addEventListener("message", function(e) {
        var o = JSON.parse(e.data);
        o.action === $35968c1d1652764a$var$t.INTERACT_MESSAGE && (o.event === $35968c1d1652764a$var$g.MESSAGE && n3.events.onMessage && o.data && n3.events.onMessage(o.data, o.client), o.event === $35968c1d1652764a$var$g.CONNECT && n3.events.onConnect && n3.events.onConnect(o.client), o.event === $35968c1d1652764a$var$g.DISCONNECT && n3.events.onDisconnect && n3.events.onDisconnect(o.client), o.event === $35968c1d1652764a$var$g.KICK && n3.events.onKick && n3.events.onKick(o.client));
    });
}, $35968c1d1652764a$var$P = new function() {
    this.all = {
        barcode: function barcode() {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.KIOSK_BARCODE
            }, undefined, 3e4);
        },
        printer: function printer(n, e) {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.KIOSK_PRINTER,
                data: n,
                printerSettings: e
            });
        }
    };
}, $35968c1d1652764a$var$C = new function() {
    this.all = {
        request: function request(n, e) {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.PROXY,
                proxy: {
                    url: n,
                    request: e
                }
            }, {
                name: n
            });
        }
    };
}, $35968c1d1652764a$var$D = new function() {
    this.all = {
        env: function env(n) {
            return $35968c1d1652764a$var$u({
                action: $35968c1d1652764a$var$t.ENV_VAR,
                name: n
            }, {
                name: n
            });
        }
    };
}, $35968c1d1652764a$var$b = function $35968c1d1652764a$var$b() {
    this.fs = $35968c1d1652764a$var$y.all, this.interactive = $35968c1d1652764a$var$m.all, this.tizen = $35968c1d1652764a$var$P.all, this.proxy = $35968c1d1652764a$var$C.all.request, this.env = $35968c1d1652764a$var$D.all.env, this.log = function(n) {
        return $35968c1d1652764a$var$a({
            action: $35968c1d1652764a$var$t.LOG,
            data: n
        });
    }, this.info = function() {
        return $35968c1d1652764a$var$u({
            action: $35968c1d1652764a$var$t.INFO
        });
    };
}, $35968c1d1652764a$var$k = {
    receiptGenerator: function() {
        var t = function t() {
            this.characters = 42, this.data = "";
        };
        return t.prototype.blank = function(t) {
            return void 0 === t && (t = 1), this.data += "".concat(" ".repeat(this.characters), "\n").repeat(t), this;
        }, t.prototype.left = function(t) {
            var n = this.characters - t.length;
            return this.data += "".concat(t).concat(" ".repeat(n), "\n"), this;
        }, t.prototype.right = function(t) {
            var n = this.characters - t.length;
            return this.data += "".concat(" ".repeat(n)).concat(t, "\n"), this;
        }, t.prototype.stretch = function(t, n, e) {
            void 0 === e && (e = " ");
            var o = this.characters - (t.length + n.length);
            return this.data += "".concat(t).concat(e.repeat(o)).concat(n, "\n"), this;
        }, t.prototype.centre = function(t) {
            var n = this.characters - t.length;
            return this.data += "".concat(" ".repeat(Math.floor(n / 2))).concat(t).concat(" ".repeat(Math.floor(n / 2)), "\n"), this;
        }, t.prototype.fill = function(t) {
            return this.data += "".concat(t.repeat(this.characters), "\n"), this;
        }, t.prototype.inject = function(t) {
            return this.data += t, this;
        }, t.prototype.generate = function(t) {
            return void 0 === t && (t = !0), t && (this.data += "".concat(" ".repeat(this.characters), "\n").repeat(6)), this.data;
        }, t;
    }()
};
!function(t) {
    t.Prod = "wss://mrx.cx/interactive/socket", t.Dev = "wss://dev.mrx.cx/interactive/socket", t.Edge = "wss://edge.mrx.cx/interactive/socket", t.Local = "ws://localhost:1337";
}($35968c1d1652764a$var$w || ($35968c1d1652764a$var$w = {})), function(t) {
    t.InitializationError = "Initialization Failed";
}($35968c1d1652764a$var$_ || ($35968c1d1652764a$var$_ = {}));
var $35968c1d1652764a$var$x = function(t6) {
    var n4 = function n4(n) {
        var e = t6.call(this, n) || this;
        return e.name = $35968c1d1652764a$var$_.InitializationError, e;
    };
    return function(t, n) {
        var e = function e() {
            this.constructor = t;
        };
        if ("function" != typeof n && null !== n) throw new TypeError("Class extends value " + String(n) + " is not a constructor or null");
        $35968c1d1652764a$var$o(t, n), t.prototype = null === n ? Object.create(n) : (e.prototype = n.prototype, new e);
    }(n4, t6), n4;
}(Error), $35968c1d1652764a$var$L = function() {
    var t7 = function t7(t8, n) {
        var e, o = this;
        if (this.sessionId = t8, this.environmentKey = n, this.socket = null, this.pingInterval = null, this.events = {
            onMessage: null,
            onOpen: null,
            onClose: null
        }, !t8) throw new $35968c1d1652764a$var$x("sessionId not provided");
        this.socket = new WebSocket("".concat((e = n, $35968c1d1652764a$var$w[e || "Prod"]), "/").concat(t8)), this.socket.onmessage = function(t) {
            if (o.events.onMessage) {
                var _$n = JSON.parse(t.data);
                "ping" !== _$n.action && "pong" !== _$n.action && o.events.onMessage(_$n.data);
            }
        }, this.socket.onopen = function() {
            o.events.onOpen && o.events.onOpen();
        }, this.socket.onclose = function(t) {
            o.events.onClose && o.events.onClose(t.code), o.destroy();
        }, this.pingInterval = window.setInterval(function() {
            return o.send("ping", "ping");
        }, 5e3);
    };
    return t7.prototype.send = function(t, n) {
        void 0 === n && (n = "message"), this.socket && this.socket.readyState === WebSocket.OPEN && this.socket.send(JSON.stringify({
            action: n,
            data: t
        }));
    }, t7.prototype.onOpen = function(t) {
        return this.events.onOpen = t.bind(this), this;
    }, t7.prototype.onClose = function(t) {
        return this.events.onClose = t.bind(this), this;
    }, t7.prototype.onMessage = function(t) {
        return this.events.onMessage = t.bind(this), this;
    }, t7.prototype.destroy = function() {
        this.socket && this.socket.close(1e3), this.events.onMessage = null, this.events.onOpen = null, this.events.onClose = null, this.socket = null, this.pingInterval && window.clearInterval(this.pingInterval);
    }, t7.urlParam = function(t) {
        return void 0 === t && (t = "session"), new URLSearchParams(window.location.search).get(t);
    }, t7;
}(), $35968c1d1652764a$export$3245ed38508723bb = function() {
    var t9 = function t9(t) {
        this.Evexi = t, this.fs().interactive().proxy("/").env({}).tizen({
            barcodeReturn: ""
        }).log().info();
    };
    return t9.prototype.fs = function() {
        var t = this;
        return this.Evexi.fs = {
            get: function get(n) {
                return $35968c1d1652764a$var$r(t, void 0, void 0, function() {
                    return $35968c1d1652764a$var$s(this, function(t) {
                        return [
                            2,
                            {
                                name: n,
                                error: null,
                                type: "text",
                                data: "text"
                            }
                        ];
                    });
                });
            },
            put: function put(n, e) {
                return $35968c1d1652764a$var$r(t, void 0, void 0, function() {
                    return $35968c1d1652764a$var$s(this, function(t) {
                        return [
                            2,
                            !0
                        ];
                    });
                });
            },
            del: function del(n) {
                return $35968c1d1652764a$var$r(t, void 0, void 0, function() {
                    return $35968c1d1652764a$var$s(this, function(t) {
                        return [
                            2,
                            !0
                        ];
                    });
                });
            },
            list: function list() {
                return $35968c1d1652764a$var$r(t, void 0, void 0, function() {
                    return $35968c1d1652764a$var$s(this, function(t) {
                        return [
                            2,
                            []
                        ];
                    });
                });
            },
            clear: function clear() {
                return $35968c1d1652764a$var$r(t, void 0, void 0, function() {
                    return $35968c1d1652764a$var$s(this, function(t) {
                        return [
                            2,
                            !0
                        ];
                    });
                });
            },
            download: function download(n, e) {
                return $35968c1d1652764a$var$r(t, void 0, void 0, function() {
                    return $35968c1d1652764a$var$s(this, function(t) {
                        return [
                            2,
                            {
                                url: n,
                                data: "",
                                error: null
                            }
                        ];
                    });
                });
            },
            exists: function exists(n) {
                return $35968c1d1652764a$var$r(t, void 0, void 0, function() {
                    return $35968c1d1652764a$var$s(this, function(t) {
                        return [
                            2,
                            !0
                        ];
                    });
                });
            }
        }, this;
    }, t9.prototype.interactive = function() {
        var t = this;
        return this.Evexi.interactive = {
            create: function create(n, e, o, i) {
                return $35968c1d1652764a$var$r(t, void 0, void 0, function() {
                    return $35968c1d1652764a$var$s(this, function(t) {
                        return [
                            2,
                            {
                                qr: "",
                                url: "",
                                sessionId: ""
                            }
                        ];
                    });
                });
            },
            start: function start() {},
            destroy: function destroy() {},
            message: function message(t, n) {},
            kick: function kick(t) {},
            onMessage: function onMessage(t) {},
            onConnect: function onConnect(t) {},
            onDisconnect: function onDisconnect(t) {},
            onKick: function onKick(t) {}
        }, this;
    }, t9.prototype.proxy = function(t10) {
        var n5 = this, e3 = function e3(e, o) {
            return $35968c1d1652764a$var$r(n5, void 0, void 0, function() {
                var n, i, _$r;
                return $35968c1d1652764a$var$s(this, function(s) {
                    switch(s.label){
                        case 0:
                            return o || (o = {}), o.headers || (o.headers = {
                                "Content-Type": "application/json"
                            }), o ? [
                                4,
                                window.fetch("".concat(t10).concat(e), o)
                            ] : [
                                3,
                                2
                            ];
                        case 1:
                            return i = s.sent(), [
                                3,
                                4
                            ];
                        case 2:
                            return [
                                4,
                                window.fetch("".concat(t10).concat(e))
                            ];
                        case 3:
                            i = s.sent(), s.label = 4;
                        case 4:
                            n = i, s.label = 5;
                        case 5:
                            return s.trys.push([
                                5,
                                7,
                                ,
                                8
                            ]), [
                                4,
                                n.json()
                            ];
                        case 6:
                            return _$r = s.sent(), [
                                3,
                                8
                            ];
                        case 7:
                            return s.sent(), [
                                2,
                                !1
                            ];
                        case 8:
                            return [
                                2,
                                {
                                    status: n.status,
                                    statusText: n.statusText,
                                    url: n.url,
                                    ok: n.ok,
                                    json: _$r
                                }
                            ];
                    }
                });
            });
        }, o2 = function o2(e, o) {
            return $35968c1d1652764a$var$r(n5, void 0, void 0, function() {
                var n;
                return $35968c1d1652764a$var$s(this, function(o) {
                    return (n = t10.find(function(t) {
                        return -1 !== e.indexOf(t.endpoint);
                    })) ? [
                        2,
                        {
                            status: 200,
                            statusText: "",
                            url: e,
                            ok: !0,
                            json: n.response
                        }
                    ] : [
                        2,
                        {
                            status: 404,
                            statusText: "Endpoint not stubbed",
                            url: e,
                            ok: !1,
                            json: undefined
                        }
                    ];
                });
            });
        };
        return this.Evexi.proxy = function(n, i) {
            return $35968c1d1652764a$var$r(this, void 0, void 0, function() {
                return $35968c1d1652764a$var$s(this, function(r) {
                    return "object" == typeof t10 ? [
                        2,
                        o2(n)
                    ] : [
                        2,
                        e3(n, i)
                    ];
                });
            });
        }, this;
    }, t9.prototype.env = function(t) {
        return this.Evexi.env = function(n) {
            return $35968c1d1652764a$var$r(this, void 0, void 0, function() {
                return $35968c1d1652764a$var$s(this, function(e) {
                    return [
                        2,
                        t[n]
                    ];
                });
            });
        }, this;
    }, t9.prototype.tizen = function(t11) {
        return this.Evexi.tizen = {
            printer: function printer(t, n) {
                return $35968c1d1652764a$var$r(this, void 0, void 0, function() {
                    return $35968c1d1652764a$var$s(this, function(e) {
                        return console.log(t, n), [
                            2,
                            Promise.resolve(!0)
                        ];
                    });
                });
            },
            barcode: function barcode() {
                var n;
                return $35968c1d1652764a$var$r(this, void 0, void 0, function() {
                    return $35968c1d1652764a$var$s(this, function(e) {
                        return [
                            2,
                            null !== (n = t11.barcodeReturn) && void 0 !== n ? n : ""
                        ];
                    });
                });
            }
        }, this;
    }, t9.prototype.log = function() {
        return this.Evexi.log = function(t) {
            console.log(t);
        }, this;
    }, t9.prototype.info = function() {
        return this.Evexi.info = function() {
            return $35968c1d1652764a$var$r(this, void 0, void 0, function() {
                return $35968c1d1652764a$var$s(this, function(t) {
                    return [
                        2,
                        {
                            deviceId: "",
                            version: "",
                            provider: !1
                        }
                    ];
                });
            });
        }, this;
    }, t9;
}(), $35968c1d1652764a$export$429f1c4820dd15e8 = function $35968c1d1652764a$export$429f1c4820dd15e8() {
    this.api = new $35968c1d1652764a$var$b, this.helper = $35968c1d1652764a$var$k, this.Scan = $35968c1d1652764a$var$L, this.env = this.api.env, this.fs = this.api.fs, this.info = this.api.info, this.interactive = this.api.interactive, this.log = this.api.log, this.proxy = this.api.proxy, this.tizen = this.api.tizen;
}, $35968c1d1652764a$export$a228efff746656cd = new $35968c1d1652764a$export$429f1c4820dd15e8;
console.log("Running Evexi API");


window.playing = function(item) {
    $b5bc41ceae313618$export$bef1f36f5486a6a3.info('playing item ...' + JSON.stringify(item));
    try {
        $35968c1d1652764a$export$a228efff746656cd ? $b5bc41ceae313618$export$bef1f36f5486a6a3.success('API Found') : $b5bc41ceae313618$export$bef1f36f5486a6a3.error('API ERROR - does not exist');
        if ($35968c1d1652764a$export$a228efff746656cd) $b5bc41ceae313618$export$bef1f36f5486a6a3.info('');
    } catch (e) {
        $b5bc41ceae313618$export$bef1f36f5486a6a3.error('API ERROR - caught');
    }
};
// @ts-ignore
window.barcode = $7be2faeb44e44bf3$export$2e2bcd8739ae039((/*@__PURE__*/$parcel$interopDefault($79ae1ae4a16b6dd8$exports)).mark(function _callee() {
    var res;
    return (/*@__PURE__*/$parcel$interopDefault($79ae1ae4a16b6dd8$exports)).wrap(function _callee$(_ctx) {
        while(1)switch(_ctx.prev = _ctx.next){
            case 0:
                $b5bc41ceae313618$export$bef1f36f5486a6a3.info(' -- TESTING BARCODE -- ');
                _ctx.prev = 1;
                _ctx.next = 4;
                return $35968c1d1652764a$export$a228efff746656cd.tizen.barcode();
            case 4:
                res = _ctx.sent;
                if (res) $b5bc41ceae313618$export$bef1f36f5486a6a3.success('BARCODE: resolved ' + JSON.stringify(res));
                else $b5bc41ceae313618$export$bef1f36f5486a6a3.error('BARCODE: false');
                _ctx.next = 11;
                break;
            case 8:
                _ctx.prev = 8;
                _ctx.t0 = _ctx["catch"](1);
                $b5bc41ceae313618$export$bef1f36f5486a6a3.error('BARCODE: caught');
            case 11:
                $b5bc41ceae313618$export$bef1f36f5486a6a3.info('');
            case 12:
            case "end":
                return _ctx.stop();
        }
    }, _callee, null, [
        [
            1,
            8
        ]
    ]);
}));
// @ts-ignore
window.print = $7be2faeb44e44bf3$export$2e2bcd8739ae039((/*@__PURE__*/$parcel$interopDefault($79ae1ae4a16b6dd8$exports)).mark(function _callee() {
    var data, res;
    return (/*@__PURE__*/$parcel$interopDefault($79ae1ae4a16b6dd8$exports)).wrap(function _callee$(_ctx) {
        while(1)switch(_ctx.prev = _ctx.next){
            case 0:
                $b5bc41ceae313618$export$bef1f36f5486a6a3.info(' -- TESTING PRINTER -- ');
                _ctx.prev = 1;
                data = "                                          \n                  EVEXI                   \n                  EVEXI                   \n                  EVEXI                   \n                  EVEXI                   \n                  EVEXI                   \n                                          \n                                          \n                                          \n                                          \n                                          \n";
                _ctx.next = 5;
                return $35968c1d1652764a$export$a228efff746656cd.tizen.printer(data);
            case 5:
                res = _ctx.sent;
                if (res) $b5bc41ceae313618$export$bef1f36f5486a6a3.success('PRINTER: resolved ' + JSON.stringify(res));
                else $b5bc41ceae313618$export$bef1f36f5486a6a3.error('PRINTER: false');
                _ctx.next = 12;
                break;
            case 9:
                _ctx.prev = 9;
                _ctx.t0 = _ctx["catch"](1);
                $b5bc41ceae313618$export$bef1f36f5486a6a3.error('PRINTER: caught');
            case 12:
                $b5bc41ceae313618$export$bef1f36f5486a6a3.info('');
            case 13:
            case "end":
                return _ctx.stop();
        }
    }, _callee, null, [
        [
            1,
            9
        ]
    ]);
}));
// @ts-ignore
window.printWrongPort = $7be2faeb44e44bf3$export$2e2bcd8739ae039((/*@__PURE__*/$parcel$interopDefault($79ae1ae4a16b6dd8$exports)).mark(function _callee() {
    var data, res;
    return (/*@__PURE__*/$parcel$interopDefault($79ae1ae4a16b6dd8$exports)).wrap(function _callee$(_ctx) {
        while(1)switch(_ctx.prev = _ctx.next){
            case 0:
                $b5bc41ceae313618$export$bef1f36f5486a6a3.info(' -- TESTING PRINTER - WRONG PORT -- ');
                _ctx.prev = 1;
                data = "                                          \n                  EVEXI                   \n                  EVEXI                   \n                  EVEXI                   \n                  EVEXI                   \n                  EVEXI                   \n                                          \n                                          \n                                          \n                                          \n                                          \n";
                _ctx.next = 5;
                return $35968c1d1652764a$export$a228efff746656cd.tizen.printer(data, {
                    port: 'PRINTERPORT0'
                });
            case 5:
                res = _ctx.sent;
                if (res) $b5bc41ceae313618$export$bef1f36f5486a6a3.success('PRINTER: resolved ' + JSON.stringify(res));
                else $b5bc41ceae313618$export$bef1f36f5486a6a3.error('PRINTER: false');
                _ctx.next = 12;
                break;
            case 9:
                _ctx.prev = 9;
                _ctx.t0 = _ctx["catch"](1);
                $b5bc41ceae313618$export$bef1f36f5486a6a3.error('PRINTER: caught' + JSON.stringify(_ctx.t0));
            case 12:
                $b5bc41ceae313618$export$bef1f36f5486a6a3.info('');
            case 13:
            case "end":
                return _ctx.stop();
        }
    }, _callee, null, [
        [
            1,
            9
        ]
    ]);
}));
/**
 * Lifecycle event to indicate the item has stopped playing
 */ window.stopping = function() {
    $b5bc41ceae313618$export$bef1f36f5486a6a3.clear();
    $b5bc41ceae313618$export$bef1f36f5486a6a3.info(' -- STOPPING -- ');
};

})();
